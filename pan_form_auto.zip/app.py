from flask import Flask, render_template, request, send_file
import fitz  # PyMuPDF
import os

app = Flask(__name__)

UPLOAD_FOLDER = "static/uploads/"
OUTPUT_FOLDER = "static/output/"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

def add_photo_signature(pdf_path, photo_path, sign_path, output_path):
    doc = fitz.open(pdf_path)
    photo_page, photo_x, photo_y = 0, 100, 500
    sign_page, sign_x, sign_y = 1, 100, 100

    photo_rect = fitz.Rect(photo_x, photo_y, photo_x + 150, photo_y + 150)
    sign_rect = fitz.Rect(sign_x, sign_y, sign_x + 100, sign_y + 50)

    doc[photo_page].insert_image(photo_rect, filename=photo_path)
    doc[sign_page].insert_image(sign_rect, filename=sign_path)

    doc.save(output_path)
    doc.close()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        pdf = request.files["pdf"]
        photo = request.files["photo"]
        sign = request.files["sign"]

        pdf_path = os.path.join(UPLOAD_FOLDER, pdf.filename)
        photo_path = os.path.join(UPLOAD_FOLDER, photo.filename)
        sign_path = os.path.join(UPLOAD_FOLDER, sign.filename)
        output_path = os.path.join(OUTPUT_FOLDER, "final_" + pdf.filename)

        pdf.save(pdf_path)
        photo.save(photo_path)
        sign.save(sign_path)

        add_photo_signature(pdf_path, photo_path, sign_path, output_path)

        return send_file(output_path, as_attachment=True)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
